package com.transithub.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "routes")
public class Route {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Destination cannot be blank")
    @Size(min = 2, max = 100, message = "Destination must be between 2 and 100 characters")
    private String destination;

    @Positive(message = "Distance must be a positive number")
    @Max(value = 10000, message = "Distance cannot exceed 10,000 km")
    private int distance;

    @NotBlank(message = "Hub name cannot be blank")
    private String hubName;

    // Default constructor required by JPA
    public Route() {}

    public Route(String destination, int distance, String hubName) {
        this.destination = destination;
        this.distance = distance;
        this.hubName = hubName;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public int getDistance() { return distance; }
    public void setDistance(int distance) { this.distance = distance; }

    public String getHubName() { return hubName; }
    public void setHubName(String hubName) { this.hubName = hubName; }

    @Override
    public String toString() {
        return "Route{id=" + id + ", destination='" + destination + "', distance=" + distance + "km, hub='" + hubName + "'}";
    }
}
