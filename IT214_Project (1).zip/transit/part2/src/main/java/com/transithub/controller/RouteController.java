package com.transithub.controller;

import com.transithub.model.Route;
import com.transithub.repository.RouteRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/**
 * REST Controller for Route management.
 * Provides CRUD endpoints for the TransitHub Route entity.
 */
@RestController
@RequestMapping("/api/transit")
@CrossOrigin(origins = "*")  // Allow CORS for frontend pages
public class RouteController {

    private final RouteRepository routeRepository;

    public RouteController(RouteRepository routeRepository) {
        this.routeRepository = routeRepository;
    }

    /**
     * GET /api/transit
     * Retrieve all routes.
     */
    @GetMapping
    public ResponseEntity<List<Route>> getAllRoutes() {
        List<Route> routes = routeRepository.findAll();
        return ResponseEntity.ok(routes);
    }

    /**
     * GET /api/transit/{id}
     * Retrieve a specific route by ID.
     * Returns 404 Not Found if the route does not exist.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Route> getRouteById(@PathVariable Long id) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Route not found with id: " + id
                ));
        return ResponseEntity.ok(route);
    }

    /**
     * POST /api/transit
     * Create a new route with full request body validation.
     * Returns 201 Created with the saved route.
     */
    @PostMapping
    public ResponseEntity<Route> createRoute(@Valid @RequestBody Route route) {
        Route savedRoute = routeRepository.save(route);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedRoute);
    }

    /**
     * PUT /api/transit/{id}
     * Update an existing route by ID.
     * Returns 404 if the route does not exist.
     */
    @PutMapping("/{id}")
    public ResponseEntity<Route> updateRoute(@PathVariable Long id, @Valid @RequestBody Route updatedRoute) {
        routeRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Route not found with id: " + id
                ));
        updatedRoute.setId(id);
        Route saved = routeRepository.save(updatedRoute);
        return ResponseEntity.ok(saved);
    }

    /**
     * DELETE /api/transit/{id}
     * Remove a route by ID.
     * Returns 204 No Content on success, 404 if not found.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRoute(@PathVariable Long id) {
        routeRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Route not found with id: " + id
                ));
        routeRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
