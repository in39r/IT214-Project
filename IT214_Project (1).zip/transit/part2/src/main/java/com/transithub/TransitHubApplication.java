package com.transithub;

import com.transithub.model.Route;
import com.transithub.repository.RouteRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class TransitHubApplication {

    public static void main(String[] args) {
        SpringApplication.run(TransitHubApplication.class, args);
    }

    // Pre-load sample data on startup
    @Bean
    CommandLineRunner initData(RouteRepository routeRepository) {
        return args -> {
            routeRepository.save(new Route("King Khalid International Airport", 35, "Riyadh Central Hub"));
            routeRepository.save(new Route("Old Town Riyadh", 15, "Riyadh Central Hub"));
            routeRepository.save(new Route("King Abdullah Financial District", 22, "Riyadh Central Hub"));
            routeRepository.save(new Route("Jeddah Islamic Port", 10, "Jeddah Port Hub"));
            routeRepository.save(new Route("Al-Balad Historic Area", 8, "Jeddah Port Hub"));
            System.out.println("✅ Sample routes loaded successfully.");
        };
    }
}
