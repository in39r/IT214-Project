package com.transithub.controller;

import com.transithub.model.Route;
import com.transithub.repository.RouteRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class WebController {

    private final RouteRepository routeRepository;

    public WebController(RouteRepository routeRepository) {
        this.routeRepository = routeRepository;
    }

    // Home page
    @GetMapping("/")
    public String home(Model model) {
        List<Route> routes = routeRepository.findAll();
        long totalHubs = routes.stream().map(Route::getHubName).distinct().count();
        double avgDistance = routes.stream().mapToInt(Route::getDistance).average().orElse(0.0);
        model.addAttribute("totalRoutes", routes.size());
        model.addAttribute("totalHubs", totalHubs);
        model.addAttribute("avgDistance", String.format("%.1f", avgDistance));
        return "index";
    }

    // Routes list
    @GetMapping("/routes")
    public String listRoutes(Model model) {
        model.addAttribute("routes", routeRepository.findAll());
        return "routes";
    }

    // Add route form
    @GetMapping("/routes/add")
    public String addRouteForm(Model model) {
        model.addAttribute("route", new Route());
        return "route-form";
    }

    // Save new route
    @PostMapping("/routes/add")
    public String saveRoute(@Valid @ModelAttribute Route route, BindingResult result,
                            RedirectAttributes attrs) {
        if (result.hasErrors()) return "route-form";
        routeRepository.save(route);
        attrs.addFlashAttribute("successMsg", "Route to '" + route.getDestination() + "' added successfully!");
        return "redirect:/routes";
    }

    // Edit form
    @GetMapping("/routes/edit/{id}")
    public String editRouteForm(@PathVariable Long id, Model model) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Route not found: " + id));
        model.addAttribute("route", route);
        return "route-form";
    }

    // Update route
    @PostMapping("/routes/edit/{id}")
    public String updateRoute(@PathVariable Long id, @Valid @ModelAttribute Route route,
                              BindingResult result, RedirectAttributes attrs) {
        if (result.hasErrors()) return "route-form";
        route.setId(id);
        routeRepository.save(route);
        attrs.addFlashAttribute("successMsg", "Route updated successfully!");
        return "redirect:/routes";
    }

    // Delete route
    @PostMapping("/routes/delete/{id}")
    public String deleteRoute(@PathVariable Long id, RedirectAttributes attrs) {
        routeRepository.deleteById(id);
        attrs.addFlashAttribute("successMsg", "Route deleted.");
        return "redirect:/routes";
    }

    // Dashboard
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        List<Route> routes = routeRepository.findAll();
        long totalHubs = routes.stream().map(Route::getHubName).distinct().count();
        double avgDistance = routes.stream().mapToInt(Route::getDistance).average().orElse(0.0);

        // Group routes by hub
        Map<String, List<Route>> routesByHub = routes.stream()
                .collect(Collectors.groupingBy(Route::getHubName));

        model.addAttribute("totalRoutes", routes.size());
        model.addAttribute("totalHubs", totalHubs);
        model.addAttribute("avgDistance", String.format("%.1f", avgDistance));
        model.addAttribute("routesByHub", routesByHub);
        return "dashboard";
    }
}
