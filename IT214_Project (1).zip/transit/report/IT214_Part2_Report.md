# IT214 – Part 2 Report: AI-Driven Development and Vibe Coding

**Course:** IT214 Object Oriented Programming – 2026
**Topic:** Conceptual Synthesis of Vibe Coding and AI-Assisted Spring Boot Development

---

## 1. What Is "Vibe Coding"?

"Vibe coding" is a development paradigm in which a programmer communicates *intent and desired outcomes* to an AI coding agent rather than writing every line of code manually. The developer describes what the system should do — its data shape, business rules, API contracts, and UI behaviours — and the AI agent (such as Cursor, Windsurf, or GitHub Copilot Workspace) scaffolds, generates, and iterates on the actual implementation.

### Contrast with Traditional Low-Code Platforms

| Dimension | Low-Code Platforms | Vibe Coding |
|---|---|---|
| **Abstraction level** | Visual drag-and-drop GUI | Natural language or structured prompts |
| **Flexibility** | Constrained by platform widgets | Full-stack generation in any framework |
| **Customisation** | Limited to available components | Can produce arbitrary logic, patterns |
| **Learning curve** | Low – business analysts can use it | Requires software design knowledge |
| **Output** | Platform-locked artifacts | Standard code (Java, Python, etc.) |

### Contrast with Standard Prompt Engineering

Prompt engineering is the craft of writing precise instructions to extract accurate, structured responses from an LLM. Vibe coding goes further: it is an *iterative loop* in which the developer provides high-level system intent ("build me a REST controller for Route with proper 404 handling and validation"), reviews the generated code for correctness, architecture fit, and security, then refines the prompt or patches the output. Whereas prompt engineering focuses on *one-shot accuracy*, vibe coding focuses on *iterative co-authorship* of a larger system.

---

## 2. The Architectural Shift in the Developer's Role

### From Implementer to Architect

Traditionally, a developer's primary value was in knowing syntax, patterns, and library APIs well enough to write correct, efficient code. With AI agents able to generate a working Spring Boot controller or React component in seconds, that tactical skill is no longer the bottleneck. The developer's value shifts up the abstraction ladder:

- **System design:** Deciding on microservice boundaries, data ownership, API contracts, and scalability trade-offs before a line of code is generated.
- **Security auditing:** AI agents may generate functional but insecure code (e.g., missing input validation, improper authentication). The developer must critically review every generated output for OWASP vulnerabilities, injection risks, and data exposure.
- **Rigorous verification:** Because the AI generates plausible-but-not-guaranteed-correct code, the developer must write tests, check edge cases, and validate that business rules are correctly encoded — roles that require deep domain understanding.
- **Ethical and compliance review:** Ensuring generated code respects privacy regulations (GDPR, PDPL in Saudi Arabia) and organisational policies.

### What This Means for Education

Students studying OOP in 2026 must therefore learn not only how to write classes and interfaces, but also how to *reason about systems* — evaluating generated code, identifying design smells, and making architectural decisions that no AI prompt alone can resolve. Part 1 of this project intentionally builds that foundational reasoning, while Part 2 practises the higher-order skill of directing and verifying AI output.

---

## 3. Spring Boot REST Service – Implementation Notes

The `RouteController` implements the full CRUD contract for the `Route` entity:

- `GET /api/transit` – returns all routes from the H2 in-memory database.
- `GET /api/transit/{id}` – returns a single route; throws `ResponseStatusException(404)` if absent.
- `POST /api/transit` – validates the request body using `@Valid` + Bean Validation (JSR-380); returns `201 Created`.
- `PUT /api/transit/{id}` – updates an existing route; returns `404` if not found.
- `DELETE /api/transit/{id}` – deletes and returns `204 No Content`.

### Design Decisions

- **JPA + H2** was chosen for zero-configuration persistence, enabling immediate `mvn spring-boot:run` without an external database.
- **Bean Validation** annotations (`@NotBlank`, `@Positive`, `@Size`) are placed on the entity itself, so validation applies consistently across both REST and Thymeleaf form submissions.
- **CORS** is enabled on the REST controller to allow the static HTML pages and potential frontend SPAs to call the API directly.

---

## 4. TransitHub Interface – Thymeleaf Pages

Four dynamic pages were developed:

| Page | Path | Purpose |
|---|---|---|
| **Home** | `/` | Overview, live stats (route count, hub count, avg distance) |
| **Routes List** | `/routes` | Tabular CRUD view with Edit and Delete buttons |
| **Add / Edit Route** | `/routes/add`, `/routes/edit/{id}` | Validated form with hub dropdown |
| **Dashboard** | `/dashboard` | Aggregated stats, routes grouped by hub, API reference table |

All pages share a consistent navigation bar and footer, using the same CSS design system (colours derived from the Saudi Public Transport Authority brand palette).

---

*End of Report – IT214 Part 2*
