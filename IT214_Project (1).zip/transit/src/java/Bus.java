public class Bus extends Vehicle {
    private boolean isElectric;

    public Bus(String id, int capacity, double currentFuel, double baseFare, boolean isElectric) {
        super(id, capacity, currentFuel, baseFare);
        this.isElectric = isElectric;
    }

    public boolean isElectric() { return isElectric; }

    @Override
    public double calculateTravelCost(int distance) {
        // Electric buses get a 20% discount
        double multiplier = isElectric ? 0.8 : 1.0;
        return baseFare + (distance * 0.5 * multiplier);
    }

    @Override
    public String toString() {
        return "Bus[id=" + getId() + ", isElectric=" + isElectric + ", capacity=" + capacity + "]";
    }
}
