import java.time.LocalDate;

public class TransitPass {
    private String passID;
    private double balance;
    private LocalDate expiryDate;

    public TransitPass(String passID, double balance, LocalDate expiryDate) {
        this.passID = passID;
        this.balance = balance;
        this.expiryDate = expiryDate;
    }

    public String getPassID() { return passID; }
    public double getBalance() { return balance; }
    public LocalDate getExpiryDate() { return expiryDate; }

    public boolean isValid() {
        return LocalDate.now().isBefore(expiryDate) || LocalDate.now().isEqual(expiryDate);
    }

    public boolean deduct(double amount) {
        if (!isValid()) {
            System.out.println("Transit pass " + passID + " has expired!");
            return false;
        }
        if (balance < amount) {
            System.out.println("Insufficient balance on pass " + passID);
            return false;
        }
        balance -= amount;
        System.out.println("Deducted " + amount + " SR from pass " + passID + ". Remaining: " + balance + " SR");
        return true;
    }

    public void topUp(double amount) {
        balance += amount;
        System.out.println("Pass " + passID + " topped up by " + amount + " SR. New balance: " + balance + " SR");
    }

    @Override
    public String toString() {
        return "TransitPass[id=" + passID + ", balance=" + balance + ", expiry=" + expiryDate + "]";
    }
}
