public class CreditCard {
    private double balance;
    private String cardNumber;   // 16 digits
    private String expiryDate;
    private int pin;             // 3 digits
    private String cardHolderName;

    public CreditCard(double balance, String cardNumber, String expiryDate, int pin, String cardHolderName) {
        if (cardNumber == null || !cardNumber.matches("\\d{16}")) {
            throw new IllegalArgumentException("Card number must be exactly 16 digits.");
        }
        if (pin < 100 || pin > 999) {
            throw new IllegalArgumentException("PIN must be exactly 3 digits.");
        }
        this.balance = balance;
        this.cardNumber = cardNumber;
        this.expiryDate = expiryDate;
        this.pin = pin;
        this.cardHolderName = cardHolderName;
    }

    public double getBalance() { return balance; }
    public String getCardHolderName() { return cardHolderName; }
    public String getMaskedNumber() { return "**** **** **** " + cardNumber.substring(12); }

    public boolean charge(double amount) {
        if (balance < amount) {
            System.out.println("Insufficient credit card balance for " + getMaskedNumber());
            return false;
        }
        balance -= amount;
        System.out.println("Charged " + amount + " SR from card " + getMaskedNumber() + ". Remaining: " + balance + " SR");
        return true;
    }

    @Override
    public String toString() {
        return "CreditCard[holder=" + cardHolderName + ", card=" + getMaskedNumber() + ", balance=" + balance + "]";
    }
}
