import java.time.LocalDate;

public class TestPart1 {
    public static void main(String[] args) {
        System.out.println("========== TransitHub System Demo ==========\n");

        // --- Create TransitHubs ---
        TransitHub hub1 = new TransitHub("Riyadh Central Hub", "Riyadh");
        TransitHub hub2 = new TransitHub("Jeddah Port Hub", "Jeddah");
        System.out.println("Hub 1: " + hub1.getHubNames());
        System.out.println("Hub 2: " + hub2.getHubNames());

        // --- Create Vehicles ---
        Bus electricBus = new Bus("BUS-001", 40, 100.0, 3.0, true);
        Bus dieselBus   = new Bus("BUS-002", 50, 80.0, 2.5, false);
        Train metro     = new Train("TRN-001", 200, 0.0, 10.0, 6);

        hub1.addVehicle(electricBus);
        hub1.addVehicle(dieselBus);
        hub1.addVehicle(metro);
        hub2.addVehicle(new Bus("BUS-003", 30, 60.0, 2.0, false));

        // --- Travel Cost Calculation ---
        System.out.println("\n--- Travel Cost Calculation (50km) ---");
        System.out.println("Electric Bus: " + electricBus.calculateTravelCost(50) + " SR");
        System.out.println("Diesel Bus:   " + dieselBus.calculateTravelCost(50) + " SR");
        System.out.println("Metro Train:  " + metro.calculateTravelCost(50) + " SR");

        // --- Create Routes ---
        System.out.println("\n--- Adding Routes ---");
        Route r1 = new Route("Airport", 35);
        Route r2 = new Route("Old Town", 15);
        Route r3 = new Route("University District", 22);
        hub1.addRoute(r1);
        hub1.addRoute(r2);
        hub1.addRoute(r3);
        System.out.println("Average route distance in " + hub1.getHubName() + ": "
                + hub1.getAverageRouteDistance() + " km");

        // --- Create Credit Cards ---
        System.out.println("\n--- Setting Up Passengers ---");
        CreditCard card1 = new CreditCard(500.0, "1234567890123456", "12/27", 123, "Ahmed Ali");
        CreditCard card2 = new CreditCard(300.0, "9876543210987654", "06/26", 456, "Ahmed Ali");
        CreditCard card3 = new CreditCard(200.0, "1111222233334444", "09/25", 789, "Sara Mohammed");

        // --- Create TransitPasses ---
        TransitPass pass1 = new TransitPass("PASS-A1", 50.0, LocalDate.of(2026, 12, 31));
        TransitPass pass2 = new TransitPass("PASS-A2", 20.0, LocalDate.of(2026, 6, 30));
        TransitPass pass3 = new TransitPass("PASS-S1", 30.0, LocalDate.of(2026, 11, 1));

        // --- Create Passengers ---
        Passenger ahmed = new Passenger("Ahmed Ali", 100.0);
        Passenger sara  = new Passenger("Sara Mohammed", 80.0);
        Passenger khalid = new Passenger("Khalid Hassan", 50.0);

        ahmed.addCreditCard(card1);
        ahmed.addCreditCard(card2);
        ahmed.addTransitPass(pass1);
        ahmed.addTransitPass(pass2);

        sara.addCreditCard(card3);
        sara.addTransitPass(pass3);

        // --- Top Up Transit Pass Using Credit Card ---
        System.out.println("\n--- Top-Up Transit Pass Using Credit Card ---");
        ahmed.topUpPassWithCard(1, 1, 30.0);  // Top up pass 1 using card 1
        ahmed.topUpPassWithCard(2, 2, 15.0);  // Top up pass 2 using card 2

        // --- Boarding ---
        System.out.println("\n--- Boarding Vehicles ---");
        ahmed.board(electricBus, 1, 35);   // boards with distance → earns FF points
        sara.board(metro, 1, 50);
        khalid.board(dieselBus, 1);        // khalid has no pass → will fail gracefully

        // Adding a pass for Khalid
        TransitPass passK = new TransitPass("PASS-K1", 100.0, LocalDate.of(2027, 1, 1));
        khalid.addTransitPass(passK);
        khalid.board(dieselBus, 1, 22);

        // --- Test Capacity Limit ---
        System.out.println("\n--- Capacity Limit Test (Bus with capacity=2 for demo) ---");
        Bus tinyBus = new Bus("BUS-TINY", 2, 50.0, 2.0, false);
        Passenger p1 = new Passenger("P1", 50); p1.addTransitPass(new TransitPass("TP1",50,LocalDate.of(2027,1,1)));
        Passenger p2 = new Passenger("P2", 50); p2.addTransitPass(new TransitPass("TP2",50,LocalDate.of(2027,1,1)));
        Passenger p3 = new Passenger("P3", 50); p3.addTransitPass(new TransitPass("TP3",50,LocalDate.of(2027,1,1)));
        p1.board(tinyBus, 1); p2.board(tinyBus, 1); p3.board(tinyBus, 1); // 3rd should fail

        // --- FrequentFlyer Points ---
        System.out.println("\n--- FrequentFlyer Points ---");
        System.out.println(ahmed.getName() + " has " + ahmed.getFrequentFlyerPoints() + " points");
        System.out.println(khalid.getName() + " has " + khalid.getFrequentFlyerPoints() + " points");

        // Give Ahmed enough points to redeem
        Passenger testRedeemer = new Passenger("Redeemer", 0);
        testRedeemer.addTransitPass(new TransitPass("TR-P1", 100, LocalDate.of(2027,1,1)));
        testRedeemer.board(electricBus, 1, 100); // earns 50 points (100km / 10 * 5)
        testRedeemer.redeemPoints();

        // --- Summary ---
        System.out.println("\n========== Final State ==========");
        System.out.println(ahmed);
        System.out.println(sara);
        System.out.println(khalid);
        System.out.println(hub1);
        System.out.println(hub2);
    }
}

