import java.util.ArrayList;

public abstract class Vehicle {
    private String id;
    public int capacity;
    public double currentFuel;
    public double baseFare;
    private ArrayList<Passenger> passengers = new ArrayList<>();

    public Vehicle(String id, int capacity, double currentFuel, double baseFare) {
        this.id = id;
        this.capacity = capacity;
        this.currentFuel = currentFuel;
        this.baseFare = baseFare;
    }

    public String getId() { return id; }

    public boolean boardPassenger(Passenger p) {
        if (passengers.size() >= capacity) {
            System.out.println("Vehicle is full! Cannot board " + p.name);
            return false;
        }
        passengers.add(p);
        return true;
    }

    public int getPassengerCount() { return passengers.size(); }

    public abstract double calculateTravelCost(int distance);

    @Override
    public String toString() {
        return "Vehicle[id=" + id + ", capacity=" + capacity + ", baseFare=" + baseFare + "]";
    }
}
