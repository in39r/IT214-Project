public class Train extends Vehicle {
    private int numberOfCarriages;
    // baseFare for a Train is a fixed constant that cannot be modified after initialization
    private final double TRAIN_BASE_FARE;

    public Train(String id, int capacity, double currentFuel, double trainBaseFare, int numberOfCarriages) {
        super(id, capacity, currentFuel, trainBaseFare);
        this.TRAIN_BASE_FARE = trainBaseFare;
        this.numberOfCarriages = numberOfCarriages;
    }

    public int getNumberOfCarriages() { return numberOfCarriages; }

    @Override
    public double calculateTravelCost(int distance) {
        return TRAIN_BASE_FARE + (distance * 0.3);
    }

    @Override
    public String toString() {
        return "Train[id=" + getId() + ", carriages=" + numberOfCarriages + ", baseFare=" + TRAIN_BASE_FARE + "]";
    }
}
