import java.util.ArrayList;

public class Passenger {
    public String name;
    private double balance;
    private ArrayList<TransitPass> transitPasses;
    private ArrayList<CreditCard> creditCards;

    // FrequentFlyer: 5 points per 10km traveled
    private int frequentFlyerPoints;
    private static final int POINTS_PER_10KM = 5;
    private static final int POINTS_TO_REDEEM = 50;
    private static final double REDEEM_VALUE = 10.0; // 50 points = 10 SR

    public Passenger(String name, double balance) {
        this.name = name;
        this.balance = balance;
        this.transitPasses = new ArrayList<>();
        this.creditCards = new ArrayList<>();
        this.frequentFlyerPoints = 0;
    }

    public double getBalance() { return balance; }
    public int getFrequentFlyerPoints() { return frequentFlyerPoints; }

    // Board a vehicle using a specific transit pass (by index)
    public boolean board(Vehicle v, int passIndex) {
        if (passIndex < 1 || passIndex > transitPasses.size()) {
            System.out.println("Invalid pass index.");
            return false;
        }
        TransitPass pass = transitPasses.get(passIndex - 1);
        double fare = v.baseFare;
        if (pass.deduct(fare)) {
            if (v.boardPassenger(this)) {
                System.out.println(name + " boarded " + v + " using pass " + pass.getPassID());
                return true;
            }
        }
        return false;
    }

    // Board with distance to earn FrequentFlyer points
    public boolean board(Vehicle v, int passIndex, int distance) {
        boolean boarded = board(v, passIndex);
        if (boarded) {
            int pointsEarned = (distance / 10) * POINTS_PER_10KM;
            frequentFlyerPoints += pointsEarned;
            System.out.println(name + " earned " + pointsEarned + " FrequentFlyer points. Total: " + frequentFlyerPoints);
        }
        return boarded;
    }

    // Add a transit pass
    public void addTransitPass(TransitPass pass) {
        transitPasses.add(pass);
        System.out.println("Pass " + pass.getPassID() + " added to " + name);
    }

    // Add a credit card
    public void addCreditCard(CreditCard card) {
        creditCards.add(card);
        System.out.println("Credit card " + card.getMaskedNumber() + " added to " + name);
    }

    // Top up a TransitPass using a credit card (by 1-based card index)
    public void topUpPassWithCard(int passIndex, int cardIndex, double amount) {
        if (passIndex < 1 || passIndex > transitPasses.size()) {
            System.out.println("Invalid pass index.");
            return;
        }
        if (cardIndex < 1 || cardIndex > creditCards.size()) {
            System.out.println("Invalid card index.");
            return;
        }
        CreditCard card = creditCards.get(cardIndex - 1);
        if (card.charge(amount)) {
            transitPasses.get(passIndex - 1).topUp(amount);
        }
    }

    // Redeem FrequentFlyer points (50 pts = 10 SR added to balance)
    public void redeemPoints() {
        if (frequentFlyerPoints < POINTS_TO_REDEEM) {
            System.out.println(name + " needs " + (POINTS_TO_REDEEM - frequentFlyerPoints) + " more points to redeem.");
            return;
        }
        int sets = frequentFlyerPoints / POINTS_TO_REDEEM;
        double earned = sets * REDEEM_VALUE;
        frequentFlyerPoints -= sets * POINTS_TO_REDEEM;
        balance += earned;
        System.out.println(name + " redeemed " + (sets * POINTS_TO_REDEEM) + " points for " + earned + " SR. Balance: " + balance + " SR");
    }

    public String getName() { return name; }
    public ArrayList<TransitPass> getTransitPasses() { return transitPasses; }
    public ArrayList<CreditCard> getCreditCards() { return creditCards; }

    @Override
    public String toString() {
        return "Passenger[name=" + name + ", balance=" + balance + " SR, passes=" + transitPasses.size() + ", points=" + frequentFlyerPoints + "]";
    }
}
