import java.util.ArrayList;

public class TransitHub {
    private String hubName;
    private String city;
    private ArrayList<Vehicle> vehicleArrayList;
    private ArrayList<Route> routes;

    public TransitHub(String hubName, String city) {
        this.hubName = hubName;
        this.city = city;
        this.vehicleArrayList = new ArrayList<>();
        this.routes = new ArrayList<>();
    }

    public String getHubName() { return hubName; }
    public String getCity() { return city; }

    // Returns all hub names in one string
    public String getHubNames() {
        return hubName + " (" + city + ")";
    }

    public void addVehicle(Vehicle v) {
        vehicleArrayList.add(v);
        System.out.println("Added " + v + " to " + hubName);
    }

    public ArrayList<Vehicle> getVehicles() { return vehicleArrayList; }

    public void addRoute(Route r) {
        routes.add(r);
        System.out.println("Added route to " + r.getDestination() + " (" + r.getDistance() + "km) in " + hubName);
    }

    public ArrayList<Route> getRoutes() { return routes; }

    public double getAverageRouteDistance() {
        if (routes.isEmpty()) return 0.0;
        int total = 0;
        for (Route r : routes) {
            total += r.getDistance();
        }
        return (double) total / routes.size();
    }

    @Override
    public String toString() {
        return "TransitHub[name=" + hubName + ", city=" + city + ", vehicles=" + vehicleArrayList.size() + ", routes=" + routes.size() + "]";
    }
}
